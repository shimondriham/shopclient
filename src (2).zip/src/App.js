// import logo from './logo.svg';
import React from 'react';
import './App.css';
import AppRoute from './appRoute';



function App() {

  return (
      <React.Fragment>
        <AppRoute />
      </React.Fragment>
   
  );
}

export default App;
