import React from 'react';

function LoginAdmin(props){
  return(
    <div>LoginAdmin work</div> 
  )
}

export default LoginAdmin